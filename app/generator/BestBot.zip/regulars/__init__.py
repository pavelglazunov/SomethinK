
import asyncio
from disnake.ext import commands
from BestBot.utils.parser import parse_config

 
from .messages import regular_message

 
from .activity_roles import start_activity_roles_updating

 
from .social_medias import check_youtube

 
async def create_all_async_process(bot: commands.Bot):
    tasks = []
     
    for r_message in parse_config("regular_messages"):
        tasks.append(asyncio.create_task(regular_message(bot=bot, message_data=r_message)))

     
    for yt in parse_config("social_media_notifications.youtube"):
        tasks.append(asyncio.create_task(check_youtube(bot=bot, yt_data=yt)))

     
    tasks.append(asyncio.create_task(start_activity_roles_updating(bot=bot)))

     
    await asyncio.gather(*tasks)
