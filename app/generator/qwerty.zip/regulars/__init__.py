
import asyncio
from disnake.ext import commands
from qwerty.utils.parser import parse_config

 
from .messages import regular_message

 
from .activity_roles import start_activity_roles_updating

 
async def create_all_async_process(bot: commands.Bot):
    tasks = []
     
    for r_message in parse_config("regular_messages"):
        tasks.append(asyncio.create_task(regular_message(bot=bot, message_data=r_message)))

     
    tasks.append(asyncio.create_task(start_activity_roles_updating(bot=bot)))

     
    await asyncio.gather(*tasks)
