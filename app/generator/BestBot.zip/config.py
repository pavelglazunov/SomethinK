
TOKEN: str = "MTEzNjMxMDI3MjY3NjU5NzkwMA.Gaz38x.J41KVa8sE9uekyCJOFJTIU8sXJKXCpcrdEvask"
SYNC_COMMANDS_DEBUG: bool = False
PREFIX: str = "/"

WARNING_JSON_FILENAME: str = "user_warnings"
CONFIG_JSON_FILENAME: str = "config"
PENDING_MESSAGES_JSON_FILENAME: str = "pending_messages"
MESSAGES_JSON_FILENAME: str = "messages_config"

LOGGING_EVENT_TYPES: tuple = ("ERRORS", "auto_moderation", "commands", )

 
WEATHER_API_KEY: str = "qwertyui"
 
GPT_API_KEY: str = "qwertyui"
