
import disnake
from disnake.ext import commands
import botFour.config as cfg
from botFour.utils.parser import parse_config
from botFour.utils.messages import send_error_message

from cogs.events_handlers import EventsCog
from cogs.help import HelpCog
from botFour.cogs.all_messages import AllMessagesCog

 
from cogs.moderation import ModerationCog
 
from cogs.another import AnotherCog

 
intents = disnake.Intents.all()
command_sync_flags = commands.CommandSyncFlags.default()
command_sync_flags.sync_commands_debug = cfg.SYNC_COMMANDS_DEBUG

bot = commands.Bot(command_prefix=cfg.PREFIX,
                   intents=intents,
                   command_sync_flags=command_sync_flags)

bot.add_cog(HelpCog(bot))
bot.add_cog(EventsCog(bot))
bot.add_cog(AllMessagesCog(bot))

 
bot.add_cog(ModerationCog(bot))
 
bot.add_cog(AnotherCog(bot))
