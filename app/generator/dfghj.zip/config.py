
TOKEN: str = "MTA4MzQxMDA4NjAyMzY3NjAxNA.G7rxTw.qmXKjgTRwZByKF2wefqYP9jKhN4xmUNmNSzDHk"
SYNC_COMMANDS_DEBUG: bool = False
PREFIX: str = "/"

WARNING_JSON_FILENAME: str = "user_warnings"
CONFIG_JSON_FILENAME: str = "config"
PENDING_MESSAGES_JSON_FILENAME: str = "pending_messages"
MESSAGES_JSON_FILENAME: str = "messages_config"

LOGGING_EVENT_TYPES: tuple = ("ERRORS", "auto_moderation", "commands", )

 