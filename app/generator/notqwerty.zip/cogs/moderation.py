
import datetime
import disnake
from disnake.ext import commands
from notqwerty.utils.parser import get_command_allow_roles, get_command_allow_channels
from notqwerty.utils.decorators import allowed_channels, allowed_roles
from notqwerty.utils.messages import send_message, get_description, send_error_message, send_long_message,     detected_error

 
from notqwerty.utils.warnings import add_warning
 
from notqwerty.utils.warnings import get_user_warnings
 
from notqwerty.utils.warnings import remove_warnings


 
class ModerationCog(commands.Cog):
    def __init__(self, bot):
        self.bot: commands.Bot = bot

     

    @commands.slash_command(name="afk", description=get_description("afk"))
    @allowed_roles(*get_command_allow_roles("afk"))
    @allowed_channels(*get_command_allow_channels("afk"))
    async def afk(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, reason: str = ""):
        """
        Переместить участника в AFK

        Parameters
        ----------
        member: Участник
        reason: Причина (необязательно)
        """
        if not member.voice:
            await send_error_message(inter, "afk_error", member)
            return

        if inter.guild.afk_channel.id != member.voice.channel.id:
            await member.move_to(inter.guild.afk_channel)
        else:
            await send_error_message(inter, "afk_already_error", member)
            return

        await send_message(inter, "afk", user=member, **{"reason": reason})

     

    @commands.slash_command(name="move", description=get_description("move"))
    @allowed_roles(*get_command_allow_roles("move"))
    @allowed_channels(*get_command_allow_channels("move"))
    async def move(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member,
                   channel: disnake.VoiceChannel, reason: str = ""):
        """
        Переместить участника в другой голосовой канал

        Parameters
        ----------
        member: Участник
        channel: Голосовой канал
        reason: Причина (необязательно)
        """
        if not member.voice:
            await send_error_message(inter, "move_error", member)
            return

        if member.voice.channel != channel:
            await member.move_to(channel)
        else:
            await send_error_message(inter, "move_new_channel_error", member)
            return 0

        await send_message(inter, "move", user=member, **{"reason": reason, "channel": channel})

     

    @commands.slash_command(name="deafen", description=get_description("deafen"))
    @allowed_roles(*get_command_allow_roles("deafen"))
    @allowed_channels(*get_command_allow_channels("deafen"))
    async def deafen(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, reason: str = ""):
        """
        Выключить звук пользователю

        Parameters
        ----------
        member: Участник
        reason: Причина (необязательно)
        """
        if member.voice:
            await member.edit(deafen=True)

            await send_message(inter, "deafen", user=member, **{"reason": reason})
        else:
            await send_error_message(inter, "deafen_error", member)

     

    @commands.slash_command(name="undeafen", description=get_description("undeafen"))
    @allowed_roles(*get_command_allow_roles("undeafen"))
    @allowed_channels(*get_command_allow_channels("undeafen"))
    async def undeafen(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, reason: str = ""):
        """
        Включить звук участнику

        Parameters
        ----------
        member: Участник
        reason: Причина (необязательно)
        """
        if member.voice:
            await member.edit(deafen=False)

            await send_message(inter, "undeafen", user=member, **{"reason": reason})
        else:
            await send_error_message(inter, "undeafen_error", member)

     

    @commands.slash_command(name="addrole", description=get_description("addrole"))
    @allowed_roles(*get_command_allow_roles("addrole"))
    @allowed_channels(*get_command_allow_channels("addrole"))
    async def addrole(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, role: disnake.Role,
                      reason: str = ""):
        """
        Выдать участнику роль

        Parameters
        ----------
        member: Участник
        role: Роль
        reason: Причина (необязательно)
        """
        if role in member.roles:
            await send_error_message(inter, "addrole_error", member)
            return
        await member.add_roles(role)
        await send_message(inter, "addrole", user=member, **{"reason": reason, "role": role})

     

    @commands.slash_command(name="rmrole", description=get_description("rmrole"))
    @allowed_roles(*get_command_allow_roles("rmrole"))
    @allowed_channels(*get_command_allow_channels("rmrole"))
    async def rmrole(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, role: disnake.Role,
                     reason: str = ""):
        """
        Удалить роль у пользователя

        Parameters
        ----------
        member: Участник
        role: Роль
        reason: Причина (необязательно)
        """
        if not (role in member.roles):
            await send_error_message(inter, "rmrole_error", member)
            return
        await member.remove_roles(role)
        await send_message(inter, "rmrole", user=member, **{"reason": reason, "role": role})

     

    @commands.slash_command(name="ping", description=get_description("ping"))
    @allowed_roles(*get_command_allow_roles("ping"))
    @allowed_channels(*get_command_allow_channels("ping"))
    async def ping(self, inter: disnake.ApplicationCommandInteraction):
        """
        Получить пинг бота

        Parameters
        ----------

        """
        await send_message(inter, "ping", user="", **{"ping": self.bot.latency})

     

    @commands.slash_command(name="slowmode", description=get_description("slowmode"))
    @allowed_roles(*get_command_allow_roles("slowmode"))
    @allowed_channels(*get_command_allow_channels("slowmode"))
    async def slowmode(self, inter: disnake.ApplicationCommandInteraction, delay: commands.Range[0, 21600],
                       reason: str = ""):
        """
        Установить медленный режим

        Parameters
        ----------
        delay: задержка в секундах (0 для выключения)
        reason: Причина (необязательно)
        """
        await inter.channel.edit(slowmode_delay=delay)
        await send_message(inter, "slowmode", user="", **{"reason": reason, "argument": delay})

     

    @commands.slash_command(name="warn", description=get_description("warn"))
    @allowed_roles(*get_command_allow_roles("warn"))
    @allowed_channels(*get_command_allow_channels("warn"))
    async def warn(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, reason: str):
        """
        Выдать предупреждение участнику

        Parameters
        ----------
        member: Участник
        reason: Причина
        """
        add_warning(member.name, inter.user.name, reason)

        await send_message(inter, "warn", user=member, **{"reason": reason})

     

    @commands.slash_command(name="warns", description=get_description("warns"))
    @allowed_roles(*get_command_allow_roles("warns"))
    @allowed_channels(*get_command_allow_channels("warns"))
    async def warns(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member):
        """
        Список предупреждений участника

        Parameters
        ----------
        member: Участник
        """
        warnings = get_user_warnings(member.name)
        embed_body = "\n".join([f"{w['id'] + 1}. {w['reason']} от {w['from']} ({w['time']})" for w in warnings])
        if not embed_body:
            embed_body = "У пользователя {} ещё нет предупреждений".format(member.name)

        await send_message(inter, "warns", user=member, **{"result": embed_body})

     

    @commands.slash_command(name="rmwarn", description=get_description("rmwarn"))
    @allowed_roles(*get_command_allow_roles("rmwarn"))
    @allowed_channels(*get_command_allow_channels("rmwarn"))
    async def rmwarn(self, inter: disnake.ApplicationCommandInteraction,
                     member: disnake.Member,
                     index: int, reason: str = ""):
        """
        Удалить предупреждение у участника

        Parameters
        ----------
        member: Участник
        index: Номер предупреждения или 0, чтобы удалить все
        reason: Причина (необязательно)
        """
        try:
            _ = get_user_warnings(member.name)[index]
        except IndexError:
            await send_error_message(inter, "rm_warns_index_error")
            return
        answer = remove_warnings(member.name, index)
        await send_message(inter, "rmwarn", user=member, **{"reason": reason, "argument": index})

     

    @commands.slash_command(name="report", description=get_description("report"))
    @allowed_roles(*get_command_allow_roles("report"))
    @allowed_channels(*get_command_allow_channels("report"))
    async def report(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member):
        """
        Пожаловаться на участника

        Parameters
        ----------
        member: Пользователь, на которого вы хотите пожаловаться
        """
        from qwerty.modals.report_modals import ReportModal
        await inter.response.send_modal(modal=ReportModal(member))

     

    
    @afk.error
    async def afk_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @move.error
    async def move_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @deafen.error
    async def deafen_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @undeafen.error
    async def undeafen_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @addrole.error
    async def addrole_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @rmrole.error
    async def rmrole_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @ping.error
    async def ping_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @slowmode.error
    async def slowmode_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @warn.error
    async def warn_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @warns.error
    async def warns_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @rmwarn.error
    async def rmwarn_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    @report.error
    async def report_error(self, ctx, error_):
        await detected_error(ctx, error_)

    
    
