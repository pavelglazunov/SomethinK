
from botFour import bot, cfg

if __name__ == '__main__':
    bot.run(cfg.TOKEN)