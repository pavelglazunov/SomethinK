
import asyncio
from disnake.ext import commands
from botFive.utils.parser import parse_config

 
async def create_all_async_process(bot: commands.Bot):
    tasks = []
     
    await asyncio.gather(*tasks)
