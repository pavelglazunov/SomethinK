
import config as cfg
from __init__ import bot


if __name__ == '__main__':
    bot.run(cfg.TOKEN)
